package uz.medion.ui.splash

import uz.medion.ui.base.BaseVM

class SplashVM: BaseVM() {
}