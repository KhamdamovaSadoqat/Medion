package uz.medion.ui.base

class BaseRes {
}