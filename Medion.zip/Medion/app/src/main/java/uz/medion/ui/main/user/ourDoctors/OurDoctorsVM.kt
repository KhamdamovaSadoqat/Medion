package uz.medion.ui.main.user.ourDoctors

import uz.medion.ui.base.BaseVM

class OurDoctorsVM: BaseVM() {
}