package uz.medion.ui.main

import uz.medion.ui.base.BaseVM

class MainVM: BaseVM() {
}