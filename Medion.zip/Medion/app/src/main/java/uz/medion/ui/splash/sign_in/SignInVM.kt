package uz.medion.ui.splash.sign_in

import uz.medion.ui.base.BaseVM

class SignInVM: BaseVM() {
}