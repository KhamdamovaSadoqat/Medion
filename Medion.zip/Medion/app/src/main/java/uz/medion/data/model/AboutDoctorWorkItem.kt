package uz.medion.data.model


data class AboutDoctorWorkItem(
    val clinicName: String,
    val sphere: String
)