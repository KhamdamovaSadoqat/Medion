package uz.medion.ui.splash.verification

import uz.medion.ui.base.BaseVM

class VerificationVM: BaseVM() {
}