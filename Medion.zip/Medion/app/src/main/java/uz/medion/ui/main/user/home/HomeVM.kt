package uz.medion.ui.main.user.home

import uz.medion.ui.base.BaseVM

class HomeVM: BaseVM() {
}