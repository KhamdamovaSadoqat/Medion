package uz.medion.data.model

import com.google.gson.annotations.SerializedName

data class SUCCESSTEST(
    @field:SerializedName("statusCode")
    val statusCode: Int? = null
)