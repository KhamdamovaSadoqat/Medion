package uz.medion.data.model

data class AboutDoctorSertificateItem(
    val image: String
)