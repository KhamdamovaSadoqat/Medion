package uz.medion.data.model

import androidx.annotation.StringRes

data class DoctorCategoryItem (
    @StringRes
    val categoryName:Int
)