package uz.medion.data.model

import androidx.annotation.StringRes

data class AboutDoctorCommentItem(
    var comment: String,
    var reyting: Int,
    var date: String

)