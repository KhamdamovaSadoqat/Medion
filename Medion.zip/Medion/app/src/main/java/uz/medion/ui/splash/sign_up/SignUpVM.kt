package uz.medion.ui.splash.sign_up

import uz.medion.ui.base.BaseVM

class SignUpVM: BaseVM() {
}