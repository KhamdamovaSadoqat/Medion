package uz.medion.ui.base

import androidx.lifecycle.ViewModel

abstract class BaseVM: ViewModel() {
}